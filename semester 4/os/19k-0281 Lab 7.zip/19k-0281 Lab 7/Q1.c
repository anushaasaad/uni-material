#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void * thread1(void *id)
{
long a=(long)id;
printf("Thread id=",a);
pthread_exit(NULL);
}
void * thread2()
{

printf("hey who is this?\n");
pthread_exit(NULL);
}
int main()
{
int status;
pthread_t tid[3];
long i;
int rc;
for(i=0;i<3;i++) {

}
for(i=0;i<3;i++) {

rc=pthread_create(&tid[i], NULL, thread1, (void *)i+1);
if(rc==0)
printf("Thread %ld returns %d\n",i+1,rc);
else
printf("Error\n");
pthread_join(tid[i],NULL);
}

return 0;}
