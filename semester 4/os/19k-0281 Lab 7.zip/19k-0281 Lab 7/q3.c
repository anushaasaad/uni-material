#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *thread(void *threadid)
{
long tid;
tid = (long)threadid;
printf("Hello I am thread; Thread id = %ld\n",tid);
sleep(1);
pthread_t thid1,thid2,thid3,thid4;
long i;
for( i=0;i<5;i++){
pthread_create(&thid1,NULL,thread,(void*)i);
pthread_create(&thid2,NULL,thread,(void*)i);
pthread_create(&thid3,NULL,thread,(void*)i);
pthread_create(&thid4,NULL,thread,(void*)i);
}
pthread_exit(NULL);

}

//void *printThread(void *thid){

//long var;
//var = (long)thid;
// printf("Hello I was created %ld \n",thid);
//}


int main(int argbb,char *arg[]){
int N=atoi(arg[1]);
printf("\n%d\n",N);
pthread_t threads[N];
int rc;
long t;
for(t=0;t < N; t++){
printf("Thread creating \n");
rc = pthread_create(&threads[t],NULL,thread,(void*)t);

if(!rc){
printf("Thread created\n");
}

else{
printf("error\n");
}
}

pthread_exit(NULL);
}
