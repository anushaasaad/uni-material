#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct data{
    int* a;
    int thread_number;
} data;

int aSize = 10;

void* Sum(void* p){
    data* ptr = (data*)p;
    int n = ptr->thread_number;

    int* thread_tot = (int*) calloc(1, sizeof(int));
    if(n == 0){
        for(int i = 0; i < aSize/2; i++)
            thread_tot[0] = thread_tot[0] + ptr->a[i];
    }
    else{
        for(int i = aSize/2; i < aSize; i++)
            thread_tot[0] = thread_tot[0] + ptr->a[i];
    }

    pthread_exit(thread_tot);
}

int main(void){
    int* int_a = (int*) calloc(aSize, sizeof(int));
    for(int i = 0; i < aSize; i++)
        int_a[i] = i + 1;
 
    data thread_data[2];
    thread_data[0].thread_number = 0;
    thread_data[0].a = int_a;
    thread_data[1].thread_number = 1;
    thread_data[1].a = int_a;
   
    pthread_t tid[2];

    pthread_create(&tid[0], NULL, halfSum, &thread_data[0]);
    pthread_create(&tid[1], NULL, halfSum, &thread_data[1]);
 
    int* sum0;
    int* sum1;

    pthread_join(tid[0], (void**)&sum0);
    pthread_join(tid[1], (void**)&sum1);
   
    printf("Sum of array = %i\n", *sum0 + *sum1);
   
    return 0;
}
