#include <iostream>
#include <string.h>
#include <conio.h>
using namespace std;
class booktype{
	string title;
	string authors[4];
	int nauthors;
	string publisher;
	int ISBN;
	double price;
	int nocopies,i;
	public:
	void settitle(string title){
		this->title=title;
	}
	void setauthors(int n){
		for(i=0; i<n; i++){
			cout<<"information of author[" <<i+1 <<"]:" <<endl;
			cout<<"name of author: " <<endl;
			cin>>authors[i];
		}
	}
	void setpublisher(string publisher){
		this->publisher=publisher;
	}
	void set_isbn(int ISBN){
		this->ISBN=ISBN;
	}
	void set_noofcopies(int nocopies){
		this->nocopies =nocopies;
	}
	void set_price(double price){
		this->price =price;
	}
	
	string gettitle(){
		return title;
	}
	int getisbn(){
		return ISBN;
	}
	void showdata(int k){
		cout<<"title: " <<title <<endl;
		cout<<"publisher:" <<publisher <<endl;
		cout<<"no of copies:" <<nocopies <<endl;
		cout<<"price: " <<price <<endl;
		cout<<"ISBN:" <<ISBN <<endl;
		for(int i=0; i<k; i++){
				cout<<"Authors " <<i+1 <<"::" <<authors[i] <<endl;
		}
	}
};
booktype b1[3];
void search(int k)
{
	char y,ch;
	int x,copies,ino,n;
	string t,name;
	cout<<"do you want to search a book(y/n):?" <<endl;
	cin>>y;
	if(y=='y'){
		cout<<"enter 1 to search by title \n 2 to search by ISBN: " <<endl;
		cin>>n;
		switch(n){
			case 1:
				cout<<"enter book title:" <<endl;
				cin>>t;
				for(int i=0; i<3; i++){
					if(b1[i].gettitle()==t){
						cout<<"do you want to modify the no of copies?:" <<endl;
						cin>>ch;
						if(ch=='y'){
							cout<<"enter no of copies again:" <<endl;
							cin>>copies;
							b1[i].set_noofcopies(copies);
							system("cls");
							b1[i].showdata(k);
						}else{
							cout<<"okay not modifying data...as you wish." <<endl;
						}
					}else{
						cout<<"invalid input." <<endl;
					}
				}
				break;
			case 2:
			    cout<<"enter the ISBN:" <<endl;
				cin>>ino;
				for(int i=0; i<3; i++){
					if(ino=b1[i].getisbn() ){
						cout<<"do you want to modify the no of copies?:" <<endl;
						cin>>ch;
						if(ch=='y'){
							cout<<"enter no of copies again:" <<endl;
							cin>>copies;
							b1[i].set_noofcopies(copies);
							system("cls");
							b1[i].showdata(k);
						}else{
							cout<<"okay not modifying data...as you wish." <<endl;
						}
					}else{
						cout<<"invalid input." <<endl;
					}
				}
				
				break;
				
		}
	}
}
int main()
{
	string t,a,pub;int isbn;
    int k;int ncop;float pr;
	booktype b1[3];
	for(int i=0; i<3; i++){
		cout<<"INFORMATION FOR BOOK " <<i+1 <<":-" <<endl;
		cout<<"enter title:" <<endl;
		cin>>t;
		b1[i].settitle(t);
		cout<<"enter no of authors from the range of 1-4" <<endl;
		cin>>k;
		b1[i].setauthors(k);
		cout<<"name of publisher:" <<endl;
		cin>>pub;
		b1[i].setpublisher(pub);
		cout<<"enter ISBN:"<<endl;
		cin>>isbn;
		b1[i].set_isbn(isbn);
		cout<<"enter no of copies in stock:" <<endl;
		cin>>ncop;
		b1[i].set_noofcopies(ncop);
		cout<<"enter price: " <<endl;
		cin>>pr;
		b1[i].set_price(pr);
	}
	system("cls");
	for(int i=0; i<3; i++){
		b1[i].showdata(k);
		cout<<endl;
	}
	search(k);
}
