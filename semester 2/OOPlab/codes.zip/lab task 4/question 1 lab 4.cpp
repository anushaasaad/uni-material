#include <iostream>
#include <string.h>
using namespace std;
class daytype{
	string day;
	string pday;
	string nday;
	int i,add;
	public:
	string wday[7];
	daytype(string day, int add){
		this->day=day;
		this->add=add;
	}
    void sday(){
	   wday[0] = "mon";
       wday[1] = "tues";
       wday[2] = "wednes";
       wday[3] = "thurs";
       wday[4] = "fri";
       wday[5] = "satur";
       wday[6] = "sun";
   }
	void setday(string d){
		if(d==wday[0]){
			i=0;
		}
		if(d==wday[1]){
			i=1;
		}
		if(d==wday[2]){
			i=2;
		}
		if(d==wday[3]){
			i=3;
		}
		if(d==wday[4]){
			i=4;
		}
		if(d==wday[5]){
			i=5;
		}
		if(d==wday[6]){
			i=6;
		}
	}
	void previousday(){
		if(i==0){
			pday=wday[6];
		}else{
			pday=wday[i-1];
		}
	}
	void nextday(){
		if(i==6){
			nday=wday[0];
			
		}else{
	    	nday=wday[i+1];
		}
	}
	void addingdays(){
		add+=i;
		if(add>=7){
			add-=7;
		}
	}
	void show(){
       cout <<"Day=" <<day <<"day" <<endl;
       cout <<"Previous day :"<<pday <<"day" <<endl;
       cout <<"Next day :" <<nday <<"day" <<endl;
       cout <<"After Adding Days :" <<wday[add] <<"day" <<endl;
  }
	
};
int main()
{
	int ad;
	string d;
	cout<<"enter day like(Sun for Sunday or thurs for thursday):" <<endl;
	cin>>d;
	cout<<"enter how manys day you want to add:" <<endl;
	cin>>ad;
	daytype d1(d,ad);
	d1.sday();
	d1.setday(d);
	d1.previousday();
	d1.nextday();
	d1.addingdays();
	d1.show();
	
}
