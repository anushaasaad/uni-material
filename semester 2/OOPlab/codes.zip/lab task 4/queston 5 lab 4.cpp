#include<iostream>
#include <string.h>
using namespace std;
class booktype
{
	string title[100][4];
	int publisher[100];
	int ISBN[100];
	
	int noofcopies[100];
	public:
		int price[100];
	void inputdata()
	{
		int i,j;
		char choice;
		for(i=0;i<100;i++)
		{
			cout<<"Informatio0n of book"<<i+1<<endl;
			for(j=0;j<4;j++)
			{
				cout<<"title  "<<i+1 <<" : ";
				cin>>title[i][j];
			}
		cout<<"Publisher:" <<endl;
		cin>>publisher[i];
		cout<<"ISBN:" <<endl;
		cin>>ISBN[i];
		cout<<"Price:" <<endl;;
		cin>>price[i];
		cout<<"no of copies:" <<endl;
		cin>>noofcopies[i];
		cout<<"do you want to enter another book information(y/n) : ";
		cin>>choice;
		if(choice=='y')
		{
			continue;
		}
		else
		{
			break;
		}
	}
	}
	int check()
	{
		string s;
		int i,count=0;
		cout<<"\n enter book title you want to search: ";
		cin>>s;
		int j;
		for(i=0;i<100;i++)
		{
			for(j=0;j<4;j++)
			{
				if(title[i][j]==s)
			{
				cout<<"\nTITLE : "<<title[i][j];
				cout<<"\nPUBLISHER : "<<publisher[i];
				cout<<"\nISBN : "<<ISBN[i];
				cout<<"\nPRICE : "<<price[i];
				cout<<"\nNO OF COPIES: "<<noofcopies[i];
				count=count+1;
			}
			}
			
			
		}
		if(count==0)
		{
				cout<<"\ninvalid title!......";
		}
		return count;
	}
};

class membertype
{
	string name;
	int id;
	int noofbooks;
	float amount;
	public:
		membertype();
		void name();
		void nobooks();
		void amount();
		void printname();
		void print_nobooks();
		void print_amount();
};		
	membertype::membertype()
	{
		cout<<"enter the name: ";
		cin>>name;
		cout<<"enter the ID : ";
		cin>>id;
		cout<<"enter no of books: ";
		cin>>nobooks;
		cout<<"enter the amount spend: ";
		cin>>amount;
		
	};
	void membertype::name()
	{
		cout<<"enter new name: ";
		cin>>name;
	}
	void membertype::nobooks()
	{
		cout<<"Enter new no of books : ";
		cin>>no_books;
	}
	void membertype::amount()
	{
		cout<<"enter new amount: ";
		cin>>amount;
	}
	void membertype::printname()
	{
		cout<<"Name : "<<name;
	}
	void membertype::print_nobooks()
	{
		cout<<"No of books: : "<<nobooks;
	}
	void membertype::print_amount()
	{
		cout<<"Amount spend : "<<amount;
	}

int main()
{
	int choice,i;
	string name;
	int fee=0;
	int count=0;
	int ch,amount;
	booktype b1;
	sos:
	cout<<"\n\t*BOOK STORE*";
	cout<<"\n\t1.Customer"<<"\n\t2.search book"<<"\n\t3.purchased no of books"<<"\n\t4.amount spend";
	cout<<"\nenter choice: ";
	cin>>ch;
	switch(ch)
	{
		case 1:
		{
			cout<<"\n\t1.new customer"<<"\n\t2.member";
			cout<<"\nenter choices: ";
			cin>>ch;
			if(ch==1)
			{
				
				cout<<"\n\tenter your name : ";
				cin>>name;
				cout<<"\n\tcongratulations on becoming the member of the book store!";
				cout<<"\n\pay the fees(10$)!";
				cin>>fee;
//				sleep(1);
				goto sos;
			}
			else if(ch==2)
			{
				cout<<"\n\tenter your name: ";
				cin>>name;
				cout<<"\n\tplease pay the fees(10$)!";
				cin>>fee;
			}
		}
		case 2:
			{
				char choices;
				if(fee==10)
				{
					cc:
					int c=b1.check();
					if(c>0)
					{
						cout<<"\n\tare you purchasing this book(y/n) ";
					cin>>choices;
					if(ch=='y')
					{
						count++;
						amount+=b1.price[i];
					}
					else
					{
						goto cc;
					}
					}
				}
				else
				{
					cout<<"first day of membership fees!.....";
//					sleep(1);
					goto sos;
				}
				
			}
		case 3:
			{
				if(count>0)
				{
					cout<<"the no of book is purchased:  "<<count;
				}
				
			}
		case 4:
			{
				cout<<"the amount spend: "<<amount;
			}
	}
}
