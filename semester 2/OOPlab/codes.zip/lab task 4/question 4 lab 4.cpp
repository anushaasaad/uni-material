#include <iostream>
#include <string.h>
#include <conio.h>
using namespace std;
class membertype{
	string name;
	string ID;
	int books;
	double amount;
	public:
		membertype(string name, string ID, int books, double amount){
			this->name=name;
			this->ID=ID;
			this->books=books;
			this->amount=amount;
		}
		void setbooks(int books){
			this->books=books;
			
		}
		void setamount(double amount){
			this->amount=amount;
		}
		int getbooks(){
			return books;
			
		}
		double getamount(){
			return amount;
		}
		void showdata(){ 
       cout <<"Name : "<< name << endl;
       cout <<"Id : "<< ID << endl;
       cout <<"Number of books: "<<getbooks() << endl;
       cout <<"amount spent: "<<getamount()  << endl;
        }
	
};
int main(){
	string n,id;
	int no,ch,nb;
	double spend,am;
	cout<<"enter name of book:" <<endl;
	cin>>n;
	cout<<"enter ID:" <<endl;
	cin>>id;
	cout<<"enter no of books bought:" <<endl;
	cin>>no;
	cout<<"enter amount spend:" <<endl;
	cin>>spend;
	membertype m1(n,id,no,spend);
	cout<<"enter 1 to modify no of books and 2 to modify amount spend" <<endl;
	cin>>ch;
	switch(ch){
		case 1:
			cout<<"enter the new no of books" <<endl;
			cin>>nb;
			m1.setbooks(nb);
			system("cls");
			m1.showdata();
			break;
		case 2:
			cout<<"enter the new amount spend" <<endl;
			cin>>am;
			m1.setamount(am);
			system("cls");
			m1.showdata();
			break;
	}
}
