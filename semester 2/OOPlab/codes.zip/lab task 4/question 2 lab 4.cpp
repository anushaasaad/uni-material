#include <iostream>
#include <string.h>
using namespace std;
class persontype{
	string firstname,f;
	string lastname,l;
	string middle;
	public:
	persontype(string firstname, string lastname, string middle){
			this->firstname=firstname;
			this->lastname=lastname;
			this->middle=middle;
			
		}
	void set_check_firstname(){
		cout<<"enter firstname to check:" <<endl;
		cin>>f;
		if(f==firstname){
			cout<<"equal" <<endl;
		}else{
			cout<<"not equal" <<endl;
		}
	}
	void set_lastname(){
		cout<<"enter lastname to check:" <<endl;
	    cin>>l;
	    if(l==lastname){
			cout<<"equal" <<endl;
		}else{
			cout<<"not equal" <<endl;
		}
	}
	
};
int main()
{
	string f,l,m;
	cout<<"enter first name:" <<endl;
	cin>>f;
	cout<<"enter last name:" <<endl;
	cin>>l;
	cout<<"enter middle name" <<endl;
	cin>>m;
	persontype p1(f,l,m);
	p1.set_check_firstname();
	p1.set_lastname();
}
