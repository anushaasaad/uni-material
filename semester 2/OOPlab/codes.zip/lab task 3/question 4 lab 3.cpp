
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class CounterType
{
	int count;
	public:
		void setcount(int c)
		{
			count=c;
		}
		void increase()
		{
			count++;
		}
		void decrease()
		{
			count--;
		}
		int getcount()
		{
			return count;
		}
		void display()
		{
			cout<<"New Count is: "<<count<<endl;
		}
};
int main()
{
	CounterType ct;
	int i;
	cout<<"Enter initial count: "<<endl;
	cin>>i;
	ct.setcount(i);
	cout<<"Initial count: "<<ct.getcount()<<endl<<endl;
	
	while(1)
  { 
	int ch;
	cout<<"1- Increase 2- Decrease 3-Display count"<<endl;
	cin>>ch;
	{
		if(ch==1)
		ct.increase();
		else if(ch==2)
		ct.decrease();
		else
		break;
	}
	
  }
	ct.display();

	return 0;
	
}
