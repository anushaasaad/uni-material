#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class bank
{
	string name;
	int accno,transaction,amount,wamount;
	float balance,interest;
	
	public:
		void input()
		{
			cout<<"Enter account balance and number of transactions: "<<endl;
		cin>>balance>>transaction;
		fflush(stdin);
		}
		void deposit()
		{
			cout<<"Enter amount to deposit: "<<endl;
			cin>>amount;
			balance=balance+amount;
		}
		void withdrawal()
		{
			cout<<"Enter amount to withdraw: "<<endl;
			cin>>wamount;
			if(wamount<=balance)
			{
				cout<<"Withdrawal succesfful!"<<endl;
			    balance=balance-wamount;
			}
			else
			cout<<"Balance not sufficient"<<endl;
		
		}
		void addinterest()
		{
			cout<<"Enter interest rate: "<<endl;
			cin>>interest;
		}
		void calcinterest()
		{
			interest=(interest*balance);
		}
		void display1()
		{
			cout<<"Your balance is: "<<balance<<endl;
		}
        void display2()
        {
        	cout<<"Number of transactions: "<<transaction<<endl;
		}
		void display3()
		{
			cout<<"Interest is: "<<interest<<endl;		
		}
	
};
int main()
{
	bank b;
	b.input();
	while(1)
   {
	cout<<"\n\n\n\n1-Display account balance\n 2-Display transactions \n3-Display interest\n 4-Make deposit \n5-Make withdrawal \n6-Add interest for this period"<<endl;
	int x;
	cout<<"Enter choice: ";
	cin>>x;
	switch(x)
	{
		case 1:
			{
				b.display1();
				break;
			}
		case 2:
			{
				b.display2();
				break;
			}
		case 3:
			{
				b.display3();
				break;
			}
		case 4:
			{
				b.deposit();
				break;
			}
		case 5:
			{
				b.withdrawal();
				break;
			}
		case 6:
			{
				b.addinterest();
				break;
			}
		default:
			{
			   return 0;
		    }
	}
   }
}
