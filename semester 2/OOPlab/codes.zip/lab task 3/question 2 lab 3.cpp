#include <iostream>
#include <string.h>
using namespace std;
class employee{
    string firstname;
    string lastname;
    int salary;
    public:
    	void setdetails(string f, string l, int s){
    		firstname=f;
    		lastname=l;
    		if(s>0){
    			salary=s;
			}else{
				salary=0;
			}
		}
		void getfirstname(){
			cout<<"first name: " <<firstname <<endl;
		}
		void getlastname(){
			cout<<"last name: " <<lastname <<endl;
		}
		void getsalary(){
			cout<<"salary: " <<salary <<endl;
		}
		void annualsalary(){
			salary=salary*12;
		}
		void raisesalary(){
			salary=salary+salary*0.1;
			annualsalary();
		}
		
		

};
int main()
{
	employee e1,e2;
	string f1,f2;
	string l1,l2;
	int s1,s2;
	cout<<"enter your first name:" <<f1 <<endl;
	cin>>f1;
	cout<<"enter your last name:" <<l1 <<endl;
	cin>>l1;
	cout<<"enter your salary:" <<s1 <<endl;
	cin>>s1;
	cout<<"enter your first name:" <<f2 <<endl;
	cin>>f2;
	cout<<"enter your last name:" <<l2 <<endl;
	cin>>l2;
	cout<<"enter your salary:" <<s2 <<endl;
	cin>>s2;
	e1.setdetails(f1,l1,s1);
	e2.setdetails(f2,l2,s2);
	e1.annualsalary();
	e2.annualsalary();
	e1.raisesalary();
	e2.raisesalary();
	cout<<"First employee details:" <<endl;
	e1.getfirstname();
	e1.getlastname();
	e1.getsalary();
	cout<<"second employee details:" <<endl;
	e2.getfirstname();
	e2.getlastname();
	e2.getsalary();
}
	
