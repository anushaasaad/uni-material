#include <iostream>
#include <string>
using namespace std;
class vector{
    int x,y;
    public:
    vector(){
    }
    vector(int x,int y){
        this->x=x;
        this->y=y;
    }
    void print(){
        cout<<"x= " <<x <<"and y= " <<y <<endl;

    }
    vector operator +(vector ob){
        vector temp;
        temp.x=this->x+ob.x;
        temp.y=this->y+ob.y;
        return temp;
    }
};
int main(){
    vector v1(4,5);
    vector v2(6,3);
    vector v3=v1+v2;
    cout<<"object v1" <<endl;
    v1.print();
    cout<<"object v2" <<endl;
    v2.print();
    cout<<"object v3" <<endl;
    v3.print();
}