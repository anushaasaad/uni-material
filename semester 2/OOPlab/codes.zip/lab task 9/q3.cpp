#include <iostream>
#include <string>
#include <math.h>
using namespace std;
class obtuse;
class acute{
    int x,y,z;
    float formula, area;
    public:
    acute(){
    }
    acute (int x,int y, int z){
        this->x=x;
        this->y=y;
        this->z=z;
        formula=(x+y+z)/2;
        area=0;
    }
    friend void calarea(acute& , obtuse& );
    void display(){
     cout <<"the area of acute triangle is: " <<area <<endl;
    }
};
class obtuse{
    int x,y,z;
    float formula, area;
    public:
    obtuse(){
    }
    obtuse (int x,int y, int z){
        this->x=x;
        this->y=y;
        this->z=z;
        formula=(x+y+z)/2;
        area=0;
    }
    friend void calarea(acute& , obtuse& );
    void display(){
     cout <<"the area of obtuse triangle is: " <<area <<endl;
    }    
};
void calarea(acute& a,obtuse& o){
    cout<<"a.acute triangle \n b.obtuse triangle "<<endl;
    char ch;
    cin>>ch;
    if(ch=='a'){
        a.area=sqrt(a.formula*((a.formula-a.x)*((a.formula-a.y))*((a.formula-a.z))));
        a.display();
    }
    if(ch=='b'){
       o.area=sqrt(o.formula*((o.formula-o.x)*((o.formula-o.y))*((o.formula-o.z))));
        o.display();
    }


};
int main(){
    acute a1(4,3,5);
    obtuse o1(5,6,8);
    calarea(a1,o1);
}
