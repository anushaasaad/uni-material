#include<iostream>
using namespace std;
class Birthday
{
	protected:
	int d,m,y;
	public:
	Birthday()
	{
		cout<<"enter the Day, Month and Year : ";
		cin>>d>>m>>y;
	}
};
class Teacher
{
	protected:
	string number,name;
	char gender;
	int age;
	public:
	Teacher()
	{
		cout<<"enter the name, number, gender(m/f) and age: ";
		cin>>name>>number>>gender>>age;
	}
};
class Professor:public Teacher,public Birthday
{
	public:
	Professor():Birthday(),Teacher()
	{}
	void get()
	{
		cout<<"name is: "<<name<<endl;
		cout<<"number is: "<<number<<endl<<"gender is : "<<gender<<endl<<"age is : "<<age<<endl<<"Birthday is : "<<d<<"/"<<m<<"/"<<y<<endl;
	}
};
int main()
{
	Professor d;
	d.get();
}
