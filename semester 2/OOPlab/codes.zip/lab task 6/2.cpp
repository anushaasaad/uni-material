#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

class Fruit
{
    protected:
    static int total;
    public:
    static void display()
    {
        cout<<"Total fruits are: "<<total<<endl;
    }
};
int Fruit::total=0;

class Apple: public Fruit
{
    public:
    int apple;
    Apple()
    {
        cout<<"How many apples?"<<endl;
        cin>>apple;
        total=total+apple;
    }
    
};

class Mango: public Fruit
{
    public:
    int mango;
    Mango()
    {
        cout<<"How many mangoes?"<<endl;
        cin>>mango;
        total=total+mango;
    }
    
};

int main()
{
    Fruit f;
    Apple a;
    Mango m;
    Fruit::display();
}
