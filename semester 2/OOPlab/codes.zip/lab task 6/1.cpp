#include<iostream>
#include<string.h>
using namespace std;
class marks{
	protected :
	int marks;
	string roll,name;
};
class physics:public marks{
	static int tm;
	public :
	physics()
	{
		cout<<"Enter name : ";
		cin>>name;
		cout<<"Enter marks in physics : ";
		cin>>marks;
		cout<<"Enter roll # : ";
		cin>>roll;
		tm=tm+marks;
	}
	void average(int cnt)
	{
		cout<<"Physics Average : "<<tm/cnt<<endl;
	}
};
int physics::tm=0;

class chemistry:public marks{
	static int tm;
	public :
	chemistry()
	{
		cout<<"Enter name : ";
		cin>>name;
		cout<<"Enter marks in chemistry : ";
		cin>>marks;
		cout<<"Enter roll # : ";
		cin>>roll;
		tm=tm+marks;
	}
	void average(int cnt)
	{
		cout<<"Chemistry Average : "<<tm/cnt<<endl;
	}
};
int chemistry::tm=0;
class maths:public marks{
	static int tm;
	public :
	maths()
	{
		cout<<"Enter name : ";
		cin>>name;
		cout<<"Enter marks in maths : ";
		cin>>marks;
		cout<<"Enter roll # : ";
		cin>>roll;
		tm=tm+marks;
	}
	void average(int cnt)
	{
		cout<<"Maths Average : "<<tm/cnt<<endl;
	}
};
int maths::tm=0;
int main()
{
	int i;
	cout<<"Enter no. of students : ";
	cin>>i;
	physics p[i];
	chemistry c[i];
	maths m[i];
	p[i-1].average(i);
	c[i-1].average(i);
	m[i-1].average(i);
}
