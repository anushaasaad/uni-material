#include <iostream>
#include <string>
using namespace std;
class marks{
	protected:
		float per;
		int a,b,c,d;
	public:
		virtual float getpercentage()=0;
};
class studentA: public marks{
	int sum;
	public:
		studentA(){
		}
		studentA(int a, int b, int c){
			this->a=a;
			this->b=b;
			this->c=c;
		}
		void cal_percentage(){
			sum=a+b+c;
			per=(sum*100)/300;
		}
		float getpercentage(){
		cout<<"Percentage of student 1: " <<per <<endl;
		}
		void print(){
				cout<<"Percentage of student 1: " <<getpercentage() <<endl;
		}
};
class studentB: public marks{
	int sum;
	public:
		studentB(){
		}
		studentB(int a, int b, int c, int d){
			this->a=a;
			this->b=b;
			this->c=c;
			this->d=d;
		}
		void cal_percentage(){
			sum=a+b+c;
			per=(sum*100)/400;
		}
		float getpercentage(){
			cout<<"Percentage of student 2: " <<per <<endl;
		}
};

int main(){
	studentA A(55,60,70);
	A.cal_percentage();
	A.getpercentage();
	studentB B(50,77,87,90);
	B.cal_percentage();
	B.getpercentage();
	
}
