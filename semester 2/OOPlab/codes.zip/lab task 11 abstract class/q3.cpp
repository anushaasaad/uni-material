#include <iostream>
#include <string.h>

using namespace std;

class shape{
	protected:
	int length, breadth, side, radius;
	public:
	virtual void rectanglearea(int length, int breadth)=0;
	virtual void squarearea(int side)=0;
	virtual void circlearea(int radius)=0;
	
};

class area: public shape{
	float R,S,C;
	public:
		void rectanglearea(int length, int breadth){
			R= length*breadth;
			cout<<"AREA OF RECTANGLE: " <<R <<endl;
		}
		void circlearea(int radius){
	    	C=3.14*radius*radius;
	    	cout<< "AREA OF CIRCLE: " <<C <<endl;
		}
		void squarearea(int side){
			S=side*side;
			cout<< "AREA OF SQUARE: " <<S <<endl;
		}
};
int main()
{
	area a;
	a.rectanglearea(4,5);
	a.circlearea(2);
	a.squarearea(4);
}

