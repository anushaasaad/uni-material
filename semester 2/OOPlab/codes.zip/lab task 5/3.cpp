#include<iostream>
#include<iomanip>
#include<string>
using namespace std;
class account
{
    string name;
    char type;
    int account_num;
    float balance_amount,rate_of_interest;
    public:
    account()
    {
        cout<<"Enter your name"<<endl;
        cin>>name;
        cout<<"Enter account number"<<endl;
        cin>>account_num;
        cout<<"Enter balance in account"<<endl;
        cin>>balance_amount;
        cout<<"Enter accout type saving(s),current(c)"<<endl;
        cin>>type;
    }
    int credit_amount()
    {
        float a;
        cout<<"Enter the amount you want to add"<<endl;
        cin>>a;
        balance_amount=balance_amount+a;
        cout<<"Amount Creditted"<<endl;
    }
    int withdraw_amount()
    {
        cout<<"your current balance is:"<<balance_amount<<endl;
        float a;
        cout<<"Enter amount you want to withdraw"<<endl;
        cin>>a;
        if(a>balance_amount)
        {
            cout<<"invalid"<<endl;
        }
        else
        {
            balance_amount=balance_amount-a;    
        }
        
    }
    int display()
    {
        cout<<"Name: "<<name<<endl;
        cout<<"balance: "<<balance_amount<<endl;
        cout<<"account type: "<<type<<endl;
        rate_of_interest=15;
        cout<<"rate of interest"<<rate_of_interest<<" "<<endl;
    }
};
int main()
{
    // account a;  
    system("cls");
    int b,i=1;
    account a;
    while(i!=0)
    {
        system("cls");
    cout<<"1:Debit\n2:credit\n3:display"<<endl;
    cin>>b;
    
    if(b==1)
    {
        a.withdraw_amount();
    }
    else if(b==2)
    {
        a.credit_amount();
    }
    else if(b==3)
    {
        a.display();
    }
    else
    {
        cout<<"Invalid input";
    }
    cout<<"Enter 0 to exit or any other key to continue"<<endl;
    cin>>i;
    }
    
}
