#include <iostream>
using namespace std;

class customer
{
    const float price=1000.85;
    string name;
    int day;
    float total
;
    public:
    customer(string xname,int xday)
    {
        name=xname;
        day=xday;
    }
    void calrentnodisc()
    {
        total=day*price;
    }
    void calrent()
    {
        if(day<=7)
        {
            calrentnodisc();
        }
        else
        {
            calrentdisc();
        }
    }
    void calrentdisc()
    {
        total=(day-1)*price;
    }
    void displayname()
    {
        cout<<"Customer Name: "<<name<<endl;
    }
    void displayday()
    {
        cout<<"Days stayed by "<<name<<": "<<day<<endl;
    }
    void displayrent()
    {
        cout<<"Rent of "<<name<<": "<<total<<endl;
    }
};
main()
{
    int choice,days;
    string e1;
    int a1;
    cout<<"Enter Name: ";
    cin>>e1;
    cout<<"Enter Day: ";
    cin>>a1;
    customer b1(e1,a1);
    start:
    cout<<"press 1. Customer Name\n2. Customer Days\n3. Rent\n";
    cin>>choice;
    switch (choice)
    {
    case 1:
        b1.displayname();
        break;
    case 2:
        b1.displayday();
        break;
    case 3:
        b1.calrent();
        b1.displayrent();
        break;
    default:
        cout<<"repeat!"<<endl;
        main();
        break;
    }
}
