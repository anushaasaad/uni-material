#include<iomanip>
#include<cstring>
#include<iostream>

using namespace std;
class employee{
    char *employeename;
    int employeeid;
    public:
    void setid(const int);
    void setname(char []);
    void display();


};
void employee::setid(const int employeeid)
    {
       this->employeeid=employeeid;
    }
    void employee::setname(char employeename[])
    {
         this->employeename=employeename;
    }
    void employee::display()
    {
        cout <<"\nYour id is \n"<<employeeid;
        cout <<"\nYour name of employee is \n";
        
        while(*employeename != '\0'){
            cout << *employeename++;
        }
    }

    int main()
    {
        int choice;
        int x;
        int employeeid;
        char ch[30];
        char *employeename;
        employeename = ch;
        cout<<"Enter the number of employee you want to add data of\n";
        cin>>x;
        employee e[x];
        for(;;)
        {
        cout<<"1-Enter data of your employee\n";
        cout<<"2-To edit the name of your employee\n";
        cout<<"3-Display data of your employee\n";
        cout<<"4-Exit from the menu\n";
        cin>>choice;
        if(choice==1)
        {
            int i;
            for(i=0;i<x;i++)
            {
            cout<<"Enter id of employee \n";
            cin>>employeeid;
            fflush(stdin);
            e[i].setid(employeeid);
            cout<<"Enter name of employee \n";
            fflush(stdin);
            cin>>ch;
                e[i].setname(ch);
            }
        }
        else if(choice==2)
        {
            int t;
            cout<<"Enter the index of employee you want to edit\n";
            cin>>t;
            cout<<"Enter the new name you want to set for the employee\n";
            fflush(stdin);
                cin>>ch;
            
            e[t].setname(ch);
        }
        else if (choice==3)
        {
            int y;
            cout<<"Enter the index of employee you want to show data of\n";
            cin>>y;
            e[y].display();

        }
        else if(choice==4)
        {
            exit(0);
        }

        }
        }
