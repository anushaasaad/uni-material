#include <iostream>
#include <string.h>
using namespace std;
class Bank{
    protected:
    	float bal;
   	public:
    float getBalance(){
	   return 0;
   }
};

class BankA : public Bank
{
    public:
    	BankA(float b){
    		bal=b;
		}
    float getBalance(){
        return bal;
    }
};
class BankB: public Bank
{
    public:
    	BankB(float b){
    		bal=b;
		}
   float getBalance(){
        return bal;
    }
};
class BankC: public Bank
{
    public:
    	BankC(float b){
    		bal=b;
		}
    float getBalance(){
        return bal;
    }
};

int main(){
	float balA, balB, balC;
    BankA a(1000);
    BankB b(1500);
    BankC c(2000);

    balA = a.getBalance();
    cout<<"The Balance in Bank A: " <<balA <<endl;
    balB = b.getBalance();
    cout<<"The Balance in Bank B: " <<balB <<endl;
    balC = c.getBalance();
    cout<<"The Balance in Bank C: " <<balC <<endl;

}
