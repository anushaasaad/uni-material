#include <iostream>
#include <string.h>
using namespace std;
class rectanglearea{
	protected:
		int len;
		int breadth;
	public:
		void area(int len, int breadth){
			
			cout<<"area of reactangle= " <<len*breadth <<endl;
		}
};
class rectangle:public rectanglearea{
	public:
	void area(int len, int breadth){
			cout<<"area of reactangle== " <<len*breadth <<endl;
		}
};
int main()
{
	int l,b;
	cout<<"enter length and breadth: " <<endl;
	cin>>l ;
	cin>>b;
	rectangle a;
	a.area(l,b);
}
