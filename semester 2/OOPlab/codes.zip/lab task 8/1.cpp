#include <iostream>
#include <string.h>
using namespace std;

class message{
	private:
	string name;
	public:
	message(string name){
		this->name=name;
	}
	void print(){
		cout<<"function without arguments will print:" <<name <<endl;
	}
	void print(string last){
		cout<<"the second function will print: " <<name <<" " <<last <<endl;
	}
};
int main(){
	string n,a;
	cout<<"enter default value first function:" <<endl;
	cin>>n;
	cout<<"enter default value second function:" <<endl;
	cin>>a;
	message m(n);
	m.print();
	m.print(a);
}
