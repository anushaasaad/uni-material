#include <iostream>
#include <string.h>
using namespace std;
class shape{
	public:
	void areaa(int len=0, int br=0){
		cout<<"No Area " <<endl;
	}
};

class area: public shape{
	public:
	void areaa(int len, int br){
		cout<<"Area of Rectangle: " <<len*br <<endl;
	}
	void areaa(int side){
		cout<<"Area of Square :" <<side*side <<endl;
	}
	
};
int main(){
	int l,b,s;
	cout<<"enter the length and breadth of rectangle: " <<endl;
	cin>>l>>b;
	cout<<"enter the sides of square:" <<endl;
	cin>>s;
	area r;
	area a;
	r.areaa(l,b);
	a.areaa(s);

	
}
