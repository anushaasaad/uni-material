#include <iostream>
#include <string>
using namespace std;
class complex{
    int comp,img;
    public:
    complex(){
    }
    complex(int c, int i){
        comp=c;
        img=i;
    }
    complex operator +(complex ob){
        complex temp;
        temp.comp=this->comp+ob.comp;
        temp.img=this->img+ob.img;
        return temp;
    }
    void display()
    {
    	cout<<"the real number is:" <<comp <<" and imaginary is:" <<img <<endl;
	}
};

int main()
{
    complex c1(2,3);
    complex c2(4,5);
    complex c3=c1+c2;
    cout<<"c1 object:" <<endl;
    c1.display();
    cout<<"c1 object:" <<endl;
    c2.display();
  
    
}
