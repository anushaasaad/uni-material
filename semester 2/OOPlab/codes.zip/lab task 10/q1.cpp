#include <iostream>
#include <string>
using namespace std;
class age{
    int a,b;
    public:
    age(int a){
        this->a=a;
    }
    void operator = (age& obj){
        if(a==obj.a){
        	cout<<"the age is equal" <<endl;

        	
		}
    }
    void operator != (age& obj){
        if(a!=obj.a){
        	cout<<"the age is not equal" <<endl;
        	
		}
    }


};
int main(){
    int x,y;
    cout<<"enter age for person 1 :" <<endl;
    cin>>x;
    age a1(x);
    cout<<"enter age for person 2 :" <<endl;
    cin>>y;
    age a2(y);
    a1=a2;
    a1!=a2;

}