#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    string a;
    char s;
    fstream f;
    f.open("abc",ios::out);
    cout<<"Enter a string: "<<endl;
    cin>>a;
    f<<a;
    int i=0;
    while(a[i])
    {
        i++;
    }
    cout<<"Length is: "<<i<<endl;
    f.close();
    //opening file to read stored string.

    f.open("abc",ios::in);
    for(int j=0;j<i;j++)
   {
       f.get(s);
       cout<<s;
   }
    f.close();
}
