#include<iostream>
#include<fstream>
using namespace std;
main()
{
	ifstream fs;
	ofstream ft;
	char ch;
	fs.open("xyz.txt");
	ft.open("bcf.txt");
	while(fs.eof()==0)                
	{ 
		fs>>ch;             //copying contents
		ft<<ch;              //pasting in other file
	}
	cout<<"File copied successfully..!!";
	fs.close();
	ft.close();
}
