#include<iostream>
#include<string>
#include<fstream>
using namespace std;

class Person
{
    string name;
    int age;
    public:
    Person()
    {}
    Person(string name, int age)
    {
        this->name=name;
        this->age=age;
    }
    void print()
    {
        cout<<"Name : "<<name<<endl;
        cout<<"Age : "<<age<<endl;
    }
};

int main()
{
    string n;
    int a;
    cout<<"Enter Name : ";
    cin>>n;
    cout<<"Enter Age : ";
    cin>>a;
    Person person1(n,a);
    Person p2;
    ofstream p("person.bin", ios::app);
    p.write((char*) &person1, sizeof(person1));
    p.close();
    ifstream per("person.bin");
    per.read((char*) &p2, sizeof(p2));
    p2.print();
    per.close();
}
