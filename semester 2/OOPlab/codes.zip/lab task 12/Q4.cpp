#include<iostream>
#include<string>
#include<fstream>
using namespace std;

class Participant
{
    string ID, name;
    int score;
    public:
    Participant(string ID, string name, int score)
    {
        this->ID=ID;
        this->name=name;
        this->score=score;
    }
    Participant()
    {}
    void Input()
    {
        ofstream i("participant.bin",ios::app);
		i.write((char*)this,sizeof(*this));
		i.close();
    }
    void print()
    {
        cout<<"ID : "<<ID<<endl;
        cout<<"Name : "<<name<<endl;
        cout<<"Score : "<<score<<endl;
    }
    void Output(string x)
	{
		ifstream f;
		f.open("participant.bin");
		while(!f.eof())
		{
			f.read((char*)this,sizeof(*this));
			if(ID==x)
			{
				print();
				break;
			}
		}
		f.close();
	}
    void Max()
	{
		Participant m("","",0);
		ifstream s;
		s.open("participant.bin");
		while(!s.eof())
		{
			s.read((char*)this,sizeof(*this));
			if(this->score>m.score)
			{
				m=*this;
			}
		}
        cout<<"Data of the highest scorer is : "<<endl;
		m.print();
	}
};

int main()
{
    string name1,name2,name3, ID1, ID2, ID3, IDs;
    int score1, score2, score3;
    cout<<"Enter the ID, name and score of participant 1 : ";
    cin>>ID1>>name1>>score1;
    Participant par1(ID1,name1,score1);
    cout<<"Enter the ID, name and score of participant 2 : ";
    cin>>ID2>>name2>>score2;
    Participant par2(ID2,name2,score2);
    cout<<"Enter the ID, name and score of participant 3 : ";
    cin>>ID3>>name3>>score3;
    Participant par3(ID3,name3,score3);
    par1.Input();
    par2.Input();
    par3.Input();
    cout<<"Enter the ID of the participant you want displayed :";
    cin>>IDs;
    Participant par4;
    par4.Output(IDs);
    par4.Max();
}
