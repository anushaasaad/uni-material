#include<iostream>
using namespace std;
void select();
struct baseball
{
    string name;
    int nhr,nh;
}b[10];
void inputdata()
{
    int i;
    for(i=0;i<10;i++)
    {
        cout<<"Enter player name : ";
        cin>>b[i].name;
        cout<<"Enter no of home runs scored : ";
        cin>>b[i].nhr;
        cout<<"Enter no of hits : ";
        cin>>b[i].nh;
    }
    system("cls");
    select();
}
void outputdata()
{
    int i;
    for(i=0;i<10;i++)
    {
        cout<<"Player name : "<<b[i].name<<endl;
        cout<<"No of home runs scored : "<<b[i].nhr<<endl;
        cout<<"No of hits : "<<b[i].nh<<endl;
    }
    select();
}
void updatedata()
{
	int x,i;
	cout<<"Enter The Index no : ";
	cin>>x;
	cout<<"Enter player name : ";
    cin>>b[x-1].name;
    cout<<"Enter no of home runs scored : ";
    cin>>b[x-1].nhr;
    cout<<"Enter no of hits : ";
    cin>>b[x-1].nh;
    cout<<endl<<"Updated ......";
    select();
}
void select()
{
	int x;
    cout<<endl<<endl<<"Select Any Option : "<<endl<<"1- Input data. "<<endl<<"2- Output data. "<<endl<<"3- Update data. "<<endl<<"4- Exit. "<<endl;
    cin>>x;
    system("cls");
	switch (x)
    {
        case 1:
        inputdata();
        break;
        case 2:
        outputdata();
        break;
        case 3:
        updatedata();
        break;
        case 4:
        exit(0);	
    }
}
int main()
{
    select();
    return 0;
}