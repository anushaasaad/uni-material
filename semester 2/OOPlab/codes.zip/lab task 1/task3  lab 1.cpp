#include<iostream>
#include<iomanip>
using namespace std;
struct menuitemtype
{
    string menuitem;
    double menuprice;
};
int main()
{
    cout<<fixed<<showpoint<<setprecision(2);
    struct menuitemtype menulist[8];
    menulist[0].menuitem="Plain Egg";
    menulist[0].menuprice=1.45;
    menulist[1].menuitem="Bacon And Egg";
    menulist[1].menuprice=2.45;
    menulist[2].menuitem="Muffin";
    menulist[2].menuprice=0.99;
    menulist[3].menuitem="French Toast";
    menulist[3].menuprice=1.99;
    menulist[4].menuitem="Fruit Basket";
    menulist[4].menuprice=2.49;
    menulist[5].menuitem="Cereal";
    menulist[5].menuprice=0.69;
    menulist[6].menuitem="Coffee";
    menulist[6].menuprice=0.50;
    menulist[7].menuitem="Tea";
    menulist[7].menuprice=0.75;
    
    int i;
    for(i=0;i<8;i++)
    {
        cout<<i+1<<"- "<<menulist[i].menuitem<<" "<<"$"<<menulist[i].menuprice<<endl;
    }
    int n;
    cout<<"Enter no. of items you want to buy : ";
    cin>>n;
    cout<<"Select the items : "<<endl;
    int x;
    struct menuitemtype newmenulist[n];
    for(i=0;i<n;i++)
    {   
        cin>>x;
        newmenulist[i].menuitem=menulist[x-1].menuitem;
        newmenulist[i].menuprice=menulist[x-1].menuprice;
    }
    cout<<"     WELCOME TO JOHNNY's RESTAURANT     "<<endl<<endl;
    for(i=0;i<n;i++)
    {
        cout<<newmenulist[i].menuitem<<" : "<<"$"<<newmenulist[i].menuprice<<endl;
    }
    float bill=0;
    for(i=0;i<n;i++)
    {
        bill=bill+newmenulist[i].menuprice;
    }
    float tax;
    tax=(5*bill)/100;
    cout<<"Tax : "<<"$"<<tax<<endl;
    cout<<"Amount Due : "<<"$"<<bill+tax<<endl<<endl;
    return 0;
}