#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    cout<<fixed<<showpoint<<setprecision(2);
    string mn;
    float atp,ctp;
    int nats,ncts;
    float pga,gross,ad;

    cout<<"Enter: \n moviename , Adult ticket price , Child ticket price , No of adult ticket sold , No of child tickets sold , Percentage of gross amount "<<endl<<endl;
    cin>>mn>>atp>>ctp>>nats>>ncts>>pga;

    cout<<"Movie name : "<<mn<<endl;
    cout<<"No. of tickets sold : "<<(nats+ncts)<<endl;
    cout<<"Gross : "<<(atp*nats)+(ctp*ncts)<<endl;
    gross=(atp*nats)+(ctp*ncts);
    cout<<"Percentage of gross amount donated : "<<pga<<endl;
    cout<<"Amount donated : "<<(gross/100) * pga<<endl;
    ad=(gross/100) * pga;
    cout<<"Net sale : "<<(gross-ad)<<endl;
    return 0;
}