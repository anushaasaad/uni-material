#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    cout<<fixed<<showpoint;
    cout<<setprecision(2);  
    int weight;
    cout<<endl<<"Enter weight in kilograms : ";
    cin>>weight;
    float pounds;
    pounds=2.2*weight;
    cout<<"Weights of the person in pounds is equal to : "<<pounds<<endl<<endl;
    return 0;
}